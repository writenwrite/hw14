import React from "react";
import Wrapper from "../component/Wrapper";
import BookForm from "../component/BookForm";

const newbook = () => {
  return (
    <Wrapper>
      <BookForm />
    </Wrapper>
  );
};

export default newbook;
